## config.py

class Config:
    """Configuration class containing game settings."""

    def __init__(self):
        # Set default values for game configuration
        self.width = 800  # Width of the game window
        self.height = 600  # Height of the game window
        self.food_size = 20  # Size of the food
        self.snake_size = 20  # Size of the snake segments

        # Define colors used in the game as a dictionary
        self.colors = {
            'black': (0, 0, 0),
            'white': (255, 255, 255),
            'red': (213, 50, 80),
            'green': (0, 255, 0),
            'blue': (50, 153, 213)
        }
