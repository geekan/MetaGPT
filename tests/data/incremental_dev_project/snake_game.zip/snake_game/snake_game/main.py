## main.py

import pygame
from game import Game

def main():
    # Initialize the game and run the game loop
    pygame.init()
    game = Game()
    game.run()

# Check if this script is run as the main program and not imported as a module
if __name__ == "__main__":
    main()
