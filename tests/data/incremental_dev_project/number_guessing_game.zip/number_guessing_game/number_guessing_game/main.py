## main.py

from ui import UI

class Main:
    def main(self):
        user_interface = UI()
        user_interface.start()

if __name__ == "__main__":
    main_instance = Main()
    main_instance.main()
