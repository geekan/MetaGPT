## main.py

import tkinter as tk
from ui import UI
from game import Game

class Main:
    @staticmethod
    def main():
        """
        The main entry point of the Gomoku game application.
        """
        game = Game()  # Create a new game instance with default board size
        app_ui = UI(game)  # Initialize the UI with the game instance
        app_ui.init_ui()  # Start the UI

# Check if the script is run directly (and not imported)
if __name__ == "__main__":
    Main.main()  # Call the main method to start the application
