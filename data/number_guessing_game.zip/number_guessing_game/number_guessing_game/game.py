## game.py

import random

class Game:
    def __init__(self, difficulty: str = 'medium'):
        self._min_range, self._max_range = self._set_difficulty(difficulty)
        self._secret_number = random.randint(self._min_range, self._max_range)
        self._attempts = []

    def _set_difficulty(self, difficulty: str):
        difficulties = {
            'easy': (1, 10),
            'medium': (1, 100),
            'hard': (1, 1000)
        }
        return difficulties.get(difficulty, (1, 100))

    def start_game(self):
        self._secret_number = random.randint(self._min_range, self._max_range)
        self._attempts = []

    def check_guess(self, guess: int) -> str:
        self._attempts.append(guess)
        if guess < self._secret_number:
            return "It's higher."
        elif guess > self._secret_number:
            return "It's lower."
        else:
            return "Correct! Game over."

    def get_attempts(self) -> int:
        return len(self._attempts)

    def get_history(self) -> list:
        return self._attempts

    def get_min_range(self) -> int:
        return self._min_range

    def get_max_range(self) -> int:
        return self._max_range
