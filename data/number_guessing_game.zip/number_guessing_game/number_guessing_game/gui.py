## gui.py
import tkinter as tk
from tkinter import messagebox
from game import Game

class GUI:
    def __init__(self, game: Game):
        self.game = game
        self.root = tk.Tk()
        self.root.title('Number Guessing Game')
        self.guess_entry = None
        self.feedback_label = None
        self.attempts_label = None
        self.history_text = None

    def setup_window(self):
        # Input field for guesses
        tk.Label(self.root, text="Enter your guess:").pack()
        self.guess_entry = tk.Entry(self.root)
        self.guess_entry.pack()

        # Button to submit guesses
        submit_button = tk.Button(self.root, text="Submit", command=self.submit_guess)
        submit_button.pack()

        # Label to display messages
        self.feedback_label = tk.Label(self.root, text="")
        self.feedback_label.pack()

        # Label to display number of attempts
        self.attempts_label = tk.Label(self.root, text="Number of attempts: 0")
        self.attempts_label.pack()

        # History of guesses
        tk.Label(self.root, text="Guess history:").pack()
        self.history_text = tk.Text(self.root, height=10, width=30)
        self.history_text.pack()

    def submit_guess(self):
        guess = self.guess_entry.get()
        if guess.isdigit():
            feedback = self.game.check_guess(int(guess))
            self.update_feedback(feedback)
            self.update_attempts(self.game.get_attempts())
            self.update_history(self.game.get_history())
            if feedback == "Correct! Game over.":
                messagebox.showinfo("Game Over", feedback)
                self.root.destroy()
        else:
            self.update_feedback("Please enter a valid number.")

    def update_feedback(self, message: str):
        self.feedback_label.config(text=message)

    def update_attempts(self, attempts: int):
        self.attempts_label.config(text=f"Number of attempts: {attempts}")

    def update_history(self, history: list):
        self.history_text.delete(1.0, tk.END)
        for guess in history:
            self.history_text.insert(tk.END, f"{guess}\n")

    def run(self):
        self.setup_window()
        self.root.mainloop()
