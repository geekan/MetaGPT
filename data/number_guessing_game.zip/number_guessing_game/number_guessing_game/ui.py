## ui.py

from game import Game

class UI:
    def __init__(self):
        self.game = None

    def start(self):
        interface_type = self.check_interface_preference()
        if interface_type == 'CLI':
            self.start_cli()
        else:
            # If GUI is preferred, the main.py will handle it
            pass

    def start_cli(self):
        difficulty = self.select_difficulty()
        self.game = Game(difficulty)
        self.game.start_game()
        self.display_welcome_message()

        feedback = ""
        while feedback != "Correct! Game over.":
            guess = self.get_user_input("Enter your guess: ")
            if self.is_valid_guess(guess):
                feedback = self.game.check_guess(int(guess))
                self.display_message(feedback)
                self.show_attempts(self.game.get_attempts())
                self.show_history(self.game.get_history())
            else:
                self.display_message("Please enter a valid number.")

    def display_welcome_message(self):
        print("Welcome to the Number Guessing Game!")
        print(f"Guess the number between {self.game.get_min_range()} and {self.game.get_max_range()}.")

    def is_valid_guess(self, guess: str) -> bool:
        return guess.isdigit()

    def display_message(self, message: str):
        print(message)

    def get_user_input(self, prompt: str) -> str:
        return input(prompt)

    def show_attempts(self, attempts: int):
        print(f"Number of attempts: {attempts}")

    def show_history(self, history: list):
        print("Guess history:")
        for guess in history:
            print(guess)

    def select_difficulty(self) -> str:
        while True:
            difficulty = input("Select difficulty (easy, medium, hard): ").lower()
            if difficulty in ['easy', 'medium', 'hard']:
                return difficulty
            else:
                self.display_message("Invalid difficulty. Please choose 'easy', 'medium', or 'hard'.")

    def check_interface_preference(self) -> str:
        preference = input("Choose interface type (CLI/GUI): ").lower()
        return 'CLI' if preference == 'cli' else 'GUI'
