## main.py
from gui import GUI
from game import Game
from ui import UI

class Main:
    def __init__(self):
        self.game = Game()
        self.ui = UI()
        self.gui = None

    def main(self):
        # Ask user for preferred interface
        interface_type = input('Choose interface type (CLI/GUI): ').lower()
        if interface_type == 'gui':
            self.gui = GUI(self.game)
            self.gui.run()
        else:
            self.ui.start()

if __name__ == '__main__':
    main_instance = Main()
    main_instance.main()
