## main.py
from game import Game

class Main:
    @staticmethod
    def main():
        """
        The main method to start the dice game.
        """
        game = Game()
        game.start_game()

# This condition checks if the script is being run as the main program and not being imported as a module.
if __name__ == "__main__":
    Main.main()
