## calculator.py

class Calculator:
    def __init__(self):
        self.result = 0.0  # Default value for the result

    def add(self, number1: float, number2: float) -> float:
        """
        Adds two numbers and returns the result.

        Args:
            number1 (float): The first number to add.
            number2 (float): The second number to add.

        Returns:
            float: The sum of number1 and number2.
        """
        self.result = number1 + number2
        return self.result

    def clear(self) -> None:
        """
        Clears the result to its default value.
        """
        self.result = 0.0
