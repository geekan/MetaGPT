## calculator.py

class Calculator:
    def add(self, number1: float, number2: float) -> float:
        """
        Add two numbers.

        Args:
            number1 (float): The first number to add.
            number2 (float): The second number to add.

        Returns:
            float: The sum of number1 and number2.
        """
        return number1 + number2

    def reset(self) -> None:
        """
        Reset the calculator to its initial state.
        This function currently does not perform any action as the calculator's
        state is not stored. It's provided for future extensibility.
        """
        pass  # No state to reset in the current implementation
