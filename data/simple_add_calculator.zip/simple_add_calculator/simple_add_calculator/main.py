## main.py
from interface import Interface


class CalculatorApp:
    @staticmethod
    def main():
        interface = Interface()
        interface.start()


if __name__ == "__main__":
    CalculatorApp.main()
